

const dummyBooks=[
    { bookName:"weee",id:1233566853,issueDate:"22/03",dueDate:"24/03",status:"not returned",action:"clear" },
    { bookName:"bituri",id:1233566854,issueDate:"22/03",dueDate:"24/03",status:"not returned",action:"clear" },
    { bookName:"fab",id:1233566855,issueDate:"22/03",dueDate:"24/03",status:"not returned",action:"clear" },
    { bookName:"vayo hano",id:1233566856,issueDate:"22/03",dueDate:"24/03",status:"not returned",action:"clear" },
    

];
  // const rows = [
  //   {
  //     bookName: "The Great Gatsby",
  //     author: "F. Scott Fitzgerald",
  //     category: "Novel",
  //     academicLevel: "S5",
  //     totalBooks: "20",
  //     availableBook: "12",
  //     language: "English",
  //     edition: "Kindle Edition",
  //     id: 1,
  //   },
  //   {
  //     bookName: "To Kill a Mockingbird",
  //     author: "Harper Lee",
  //     category: "Action",
  //     academicLevel: "S6",
  //     totalBooks: "10",
  //     availableBook: "4",
  //     language: "French",
  //     edition: "French Edition 1998",
  //     id: 2,
  //   },
  //   {
  //     bookName: "The Lord of the Rings",
  //     author: "J. R. R. Tolkien",
  //     category: "Fantasy",
  //     academicLevel: "S4",
  //     totalBooks: "11",
  //     availableBook: "8",
  //     language: "English",
  //     edition: "The Rings of Power 1954",
  //     id: 3,
  //   },
  //   {
  //     bookName: "Animal Farm",
  //     author: "George Orwell",
  //     category: "History",
  //     academicLevel: "S2",
  //     totalBooks: "10",
  //     availableBook: "2",
  //     language: "Danish",
  //     edition: "A Fairy Story 1944",
  //     id: 4,
  //   },
  //   {
  //     bookName: "Pride and Prejudice",
  //     author: "Jane Austen",
  //     category: "Romance",
  //     academicLevel: "S2",
  //     totalBooks: "30",
  //     availableBook: "12",
  //     language: "Spanish",
  //     edition: "Deluxe edition(Spanish) 1813",
  //     id: 5,
  //   },
  //   {
  //     bookName: "Beloved",
  //     author: "Toni Morrison",
  //     category: "Novel",
  //     academicLevel: "S1",
  //     totalBooks: "15",
  //     availableBook: "7",
  //     language: "English",
  //     edition: "Paperback 1987",
  //     id: 6,
  //   },
  // ];
export default dummyBooks;